package dev.aurakai.auraframefx.di.qualifiers

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class AiMemory

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class GenesisMemory
